$.ajax({
    url: "https://formspree.io/xndogykx", 
    method: "POST",
    data: {message: "hello!"},
    dataType: "json"
});